## 0.1.0 (Jan. 9, 2019)

#### FEATURES:

* support standalone seata-server.
* support mysql automatic transaction.
* support @GlobalTransactional spring annotation.
* support dubbo on filter.
* support mybatis ORM framework.
* support api&template.
* support dubbo，springcloud，motan ect.